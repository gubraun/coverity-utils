@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.coverity.com/v7")
package com.coverity.ws.v7;
